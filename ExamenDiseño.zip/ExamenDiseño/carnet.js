// carnet.js

function obtenerIdPaciente() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// Función para obtener la información del paciente desde el servidor
async function obtenerDatosPaciente() {
    try {
        const idPaciente = obtenerIdPaciente(); // Asegúrate de tener esta función implementada
        const response = await fetch(`http://localhost:3000/obtener-paciente/${idPaciente}`);
        if (response.ok) {
            const paciente = await response.json();
            mostrarCarnet(paciente);
        } else {
            console.error('Error al obtener datos del paciente:', response.statusText);
        }
    } catch (error) {
        console.error('Error al obtener datos del paciente:', error);
    }
}

// Función para mostrar el carné con los datos del paciente
function mostrarCarnet(paciente) {
    const carnetContainer = document.getElementById('carnet-container');

    // Crea el contenido del carné con los datos del paciente
    const carnetHTML = `
        <div class="carnet">
            <h2>Carnet de Mascota</h2>
            <p><strong>Nombre:</strong> ${paciente.nombre}</p>
            <p><strong>Cédula:</strong> ${paciente.cedula}</p>
            <p><strong>Mascota:</strong> ${paciente.mascota}</p>
            <p><strong>Raza:</strong> ${paciente.raza}</p>
            <p><strong>Edad:</strong> ${paciente.edad}</p>
            <!-- Agrega más campos según sea necesario -->
        </div>
    `;

    // Inserta el carné en el contenedor
    carnetContainer.innerHTML = carnetHTML;
}

// Llama a la función para obtener y mostrar los datos del paciente al cargar la página
window.onload = obtenerDatosPaciente;
