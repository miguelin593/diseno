function obtenerIdPaciente() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// Función para cargar los datos del paciente con el ID proporcionado
async function cargarDatosPaciente() {
    const idPaciente = obtenerIdPaciente();

    try {
        const response = await fetch(`http://localhost:3000/obtener-datos-paciente?id=${idPaciente}`);
        const datosPaciente = await response.json();

        // Llena los campos del formulario con los datos obtenidos
        document.getElementById('nombre').value = datosPaciente.nombre;
        document.getElementById('cedula').value = datosPaciente.cedula;
        document.getElementById('mascota').value = datosPaciente.mascota;
        document.getElementById('raza').value = datosPaciente.raza;
        document.getElementById('edad').value = datosPaciente.edad;
        document.getElementById('sexo').value = datosPaciente.sexo;
        document.getElementById('color').value = datosPaciente.color;
        document.getElementById('residencia').value = datosPaciente.residencia;
    } catch (error) {
        console.error('Error al cargar datos del paciente:', error);
    }
}

// Llama a la función para cargar datos cuando la página se carga
window.onload = cargarDatosPaciente;

async function guardarEdicion() {
    // Obtén los valores de los campos de edición
    const nombre = document.getElementById('nombre').value;
    const cedula = document.getElementById('cedula').value;
    const mascota = document.getElementById('mascota').value;
    const raza = document.getElementById('raza').value;
    const edad = document.getElementById('edad').value;
    const sexo = document.getElementById('sexo').value;
    const color = document.getElementById('color').value;
    const residencia = document.getElementById('residencia').value;

    // Construye el objeto con los nuevos datos
    const nuevosDatos = {
        nombre: nombre,
        cedula: cedula,
        mascota: mascota,
        raza: raza,
        edad: edad,
        sexo: sexo,
        color: color,
        residencia: residencia
        // Agrega más campos si es necesario
    };

    // ID del paciente (obtenido de la URL, por ejemplo)
    const idPaciente = obtenerIdPaciente();

    // Realiza la solicitud al servidor para actualizar los datos
    try {
        const response = await fetch(`http://localhost:3000/editar-paciente/${cedula}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(nuevosDatos),
        });

        if (response.ok) {
            // Datos actualizados con éxito
            const confirmacion = window.confirm('Edición exitosa. ¿Deseas volver a la lista de pacientes?');
            if (confirmacion) {
                // Redirige a la lista de pacientes
                window.location.href = 'C:/Users/Miguel/Documents/ExamenDiseño/lista.html';
                console.log('Datos actualizados con éxito');
            }
            
        } else {
            // Error al actualizar datos
            console.error('Error al actualizar datos');
        }
    } catch (error) {
        console.error('Error en la solicitud:', error);
    }
}