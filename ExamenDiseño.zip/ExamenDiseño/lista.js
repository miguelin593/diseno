// lista.js
document.addEventListener('DOMContentLoaded', function () {
    cargarListaPacientes();
});

function cargarListaPacientes() {
    fetch('http://localhost:3000/lista-pacientes')
        .then(response => response.json())
        .then(data => {
            const listaPacientes = document.getElementById('lista-pacientes');
            listaPacientes.innerHTML = '';

            data.forEach(paciente => {
                const listItem = document.createElement('li');
                listItem.className = 'list-group-item';
                listItem.innerHTML = `
                    ${paciente.nombre} (${paciente.cedula})
                    <button class="btn btn-warning btn-sm" onclick="editarPaciente(this)" data-id="${paciente.id}">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarPaciente(${paciente.id})">Eliminar</button>
                    <button class="btn btn-primary btn-sm" onclick="generarCarnet(${paciente.id})">Generar Carnet</button>
                `;
                listaPacientes.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error al cargar la lista de pacientes:', error);
        });
}

function generarCarnet(id) {
    // Redirigir a la página de carné con el id del paciente
    window.location.href = `C:/Users/Miguel/Documents/ExamenDiseño/carnet.html?id=${id}`;
}



function editarPaciente(button) {
    const idPaciente = button.dataset.id;

    // Redirigir a la página de edición con el id del paciente
    window.location.href = `C:/Users/Miguel/Documents/ExamenDiseño/editar.html?id=${idPaciente}`;
}




function eliminarPaciente(id) {
    fetch(`http://localhost:3000/eliminar-paciente/${id}`, {
      method: 'DELETE',
    })
      .then(response => {
        if (!response.ok) {
          throw new Error(`Error en la solicitud: ${response.statusText}`);
        }
        return response.json();
      })
      .then(data => {
        alert(data.message);
        location.reload(); // Recarga la página después de eliminar
      })
      .catch(error => {
        console.error('Error al eliminar paciente:', error);
        alert('Error al eliminar paciente');
      });
  }

