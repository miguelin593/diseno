// registro.js
function registrarPaciente() {
    // Obtener todos los elementos del formulario
    
    const mascotaElement = document.getElementById('mascota');
    const razaElement = document.getElementById('raza');
    const edadElement = document.getElementById('edad');
    const sexoElement = document.getElementById('sexo');
    const colorElement = document.getElementById('color');
    const residenciaElement = document.getElementById('residencia');
    const nombreElement = document.getElementById('nombre');
    const cedulaElement = document.getElementById('cedula');

    // Verificar si los elementos existen antes de intentar acceder a sus valores
    if (!nombreElement || !mascotaElement || !razaElement || !edadElement || !sexoElement || !colorElement || !residenciaElement || !cedulaElement) {
        console.error('Alguno de los elementos no se encontró en el DOM.');
        return;
    }

    // Obtener los valores de los elementos
    
    const mascota = mascotaElement.value;
    const raza = razaElement.value;
    const edad = edadElement.value;
    const sexo = sexoElement.value;
    const color = colorElement.value;
    const residencia = residenciaElement.value;
    const cedula = cedulaElement.value;
    const nombre = nombreElement.value;

    // Crear un objeto con todos los datos del paciente
    const nuevoPaciente = {
        mascota,
        raza,
        edad,
        sexo,
        color,
        residencia,
        cedula,
        nombre,
    };

    // Enviar la solicitud para registrar el paciente
fetch('http://localhost:3000/registrar-paciente', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(nuevoPaciente),
})
.then(response => {
    if (!response.ok) {
        throw new Error(`Error en la solicitud: ${response.statusText}`);
    }
    // Imprimir la respuesta completa para depuración
    console.log(response);
    return response.json();
})
.then(data => {
    alert('Paciente registrado con éxito');
    // Puedes redirigir o hacer cualquier otra acción después de registrar el paciente
})
.catch(error => {
    console.error('Error al registrar paciente:', error);
    alert('Error al registrar paciente');
});
}
