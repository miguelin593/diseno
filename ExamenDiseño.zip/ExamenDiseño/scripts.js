

document.addEventListener('DOMContentLoaded', function () {
    // Cargar citas almacenadas al cargar la página
    let citas = cargarCitas() || [];

    // Función para cargar citas desde el almacenamiento local
    function cargarCitas() {
        const citasString = localStorage.getItem('citas');
        return citasString ? JSON.parse(citasString) : [];
    }

    // Función para guardar citas en el almacenamiento local
    function guardarCitas() {
        localStorage.setItem('citas', JSON.stringify(citas));
    }

    // Función para verificar si una cédula ya tiene una cita
    function cedulaYaTieneCita(cedula) {
        return citas.some(cita => cita.cedula === cedula);
    }

    // Función para verificar si ya hay una cita agendada para la misma hora y día
    function horaCitaOcupada(horaCita, diaCita) {
        return citas.some(cita => cita.horaCita === horaCita && cita.diaCita === diaCita);
    }

    // Función para agendar una cita
    window.agendarCita = function () {
        const nombreCliente = document.getElementById('nombreCliente').value;
        const cedula = document.getElementById('cedula').value;
        const nombreMascota = document.getElementById('nombreMascota').value;
        const horaCita = document.getElementById('horaCita').value;
        const diaCita = document.getElementById('diaCita').value;

        // Lógica para verificar que la cita sea hasta una semana después
        const fechaActual = new Date();
        const fechaCita = new Date(diaCita);
        const unaSemanaDespues = new Date(fechaActual);
        unaSemanaDespues.setDate(fechaActual.getDate() + 7);

        if (fechaCita > fechaActual && fechaCita <= unaSemanaDespues) {
            // La cita es válida
            if (!cedulaYaTieneCita(cedula)) {
                if (!horaCitaOcupada(horaCita, diaCita)) {
                    const nuevaCita = {
                        nombreCliente: nombreCliente,
                        cedula: cedula,
                        nombreMascota: nombreMascota,
                        horaCita: horaCita,
                        diaCita: diaCita
                    };

                    // Agregar la nueva cita al array
                    citas.push(nuevaCita);

                    // Guardar el array de citas en el almacenamiento local
                    guardarCitas();

                    // Mostrar la lista actualizada de citas
                    mostrarCitas();

                    alert('Cita agendada con éxito');
                } else {
                    alert('Ya hay una cita agendada para esa hora y día.');
                }
            } else {
                alert('Ya existe una cita registrada para esta cédula.');
            }
        } else {
            alert('La cita no es válida. Asegúrate de que sea hasta una semana después del día actual.');
        }
    };

    // Función para mostrar la lista de citas
    function mostrarCitas() {
        const listaCitas = document.getElementById('listaCitas');
        listaCitas.innerHTML = '';

        citas.forEach((cita, index) => {
            const listItem = document.createElement('li');
            listItem.className = 'list-group-item';
            listItem.innerHTML = `<strong>${cita.nombreCliente}</strong> - Cédula: ${cita.cedula} - ${cita.nombreMascota} - ${cita.horaCita} - ${cita.diaCita} 
                <button type="button" class="btn btn-danger btn-sm float-right" onclick="eliminarCita(${index})">Eliminar</button>`;
            listaCitas.appendChild(listItem);
        });
    }

       // Agrega esto en tu scripts.js
       function buscarCitaPorCedula() {
        const cedulaABuscar = document.getElementById('buscarCedula').value;
    
        // Verifica si la cédula ingresada existe en las citas
        const citaEncontrada = citas.find(cita => cita.cedula === cedulaABuscar);
    
        const resultadoContainer = document.getElementById('resultadoBusqueda');
    
        if (citaEncontrada) {
            resultadoContainer.innerHTML = `<p>Cita encontrada:</p>
            <p>Nombre: ${citaEncontrada.nombreCliente}</p>
            <p>Mascota: ${citaEncontrada.nombreMascota}</p>
            <p>Hora: ${citaEncontrada.horaCita}</p>
            <p>Día: ${citaEncontrada.diaCita}</p>`;
        } else {
            resultadoContainer.innerHTML = '<p>No se encontró ninguna cita para la cédula ingresada.</p>';
        }
    }


    window.generarReporte = function () {
        // Obtener el contenido de las citas formateado
        const contenidoReporte = citas.map((cita, index) => {
            return `${index + 1}. Cliente: ${cita.nombreCliente}, Cédula: ${cita.cedula}, Mascota: ${cita.nombreMascota}, Hora: ${cita.horaCita}, Día: ${cita.diaCita}`;
        }).join('\n');
    
        // Crear un Blob con el contenido y el tipo de archivo
        const blob = new Blob([contenidoReporte], { type: 'text/plain' });
    
        // Crear una URL para el Blob
        const url = URL.createObjectURL(blob);
    
        // Crear un enlace (a) para descargar el archivo
        const a = document.createElement('a');
        a.href = url;
        a.download = 'reporte_citas.txt';
    
        // Agregar el enlace al documento y hacer clic en él para iniciar la descarga
        document.body.appendChild(a);
        a.click();
    
        // Eliminar el enlace del documento después de la descarga
        document.body.removeChild(a);
    };
    
    

    // Función para eliminar una cita
    window.eliminarCita = function (index) {
        citas.splice(index, 1);
        guardarCitas();
        mostrarCitas();
    };

    // Mostrar las citas al cargar la página
    mostrarCitas();


 


});
