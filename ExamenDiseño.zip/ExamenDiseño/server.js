// server.js
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const cors = require('cors');  // Agrega esta línea

const app = express();
app.use(cors());  // Agrega esta línea
app.use(bodyParser.json());

// Configuración de la conexión a PostgreSQL
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'veterinaria',
  password: '1234',
  port: 5432,
});

// Manejo de errores de conexión a la base de datos
pool.connect((err, client, release) => {
  if (err) {
    return console.error('Error al conectar con la base de datos:', err);
  }
  console.log('Conexión exitosa a la base de datos');
  release();
});

// Función para actualizar un paciente
async function actualizarPaciente(id, nuevosDatos) {
  const { mascota, raza, edad, sexo, color, residencia, cedula, nombre } = nuevosDatos;
  const query = 'UPDATE registro SET mascota = $1, raza = $2, edad = $3, sexo = $4, color = $5, residencia = $6, cedula = $7, nombre = $8 WHERE id = $9 RETURNING *';
  const values = [mascota, raza, edad, sexo, color, residencia, cedula, nombre, id];

  try {
    const result = await pool.query(query, values);
    return result.rows[0];
  } catch (error) {
    throw error;
  }
}

// Ruta para editar un paciente
app.put('/editar-paciente/:cedula', async (req, res) => {
  const cedula = req.params.cedula;
  const nuevosDatos = req.body;

  try {
    const pacienteActualizado = await actualizarPaciente(cedula, nuevosDatos);
    res.json(pacienteActualizado);
  } catch (error) {
    console.error('Error al editar paciente:', error);
    res.status(500).send('Error interno del servidor');
  }
});

// Función para eliminar un paciente
async function eliminarPaciente(cedula) {
  try {
    const query = 'DELETE FROM registro WHERE cedula = $1 RETURNING *';
    const result = await pool.query(query, [cedula]);
    return result.rows[0];
  } catch (error) {
    throw error;
  }
}

// Función para insertar un nuevo paciente
async function insertarPaciente(datosPaciente) {
  const { mascota, raza, edad, sexo, color, residencia, cedula, nombre } = datosPaciente;
  const query = 'INSERT INTO registro(mascota, raza, edad, sexo, color, residencia, cedula, nombre) VALUES($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *';
  const values = [mascota, raza, edad, sexo, color, residencia, cedula, nombre];

  try {
    const result = await pool.query(query, values);
    return result.rows[0];
  } catch (error) {
    throw error;
  }
}

// Rutas
app.post('/registrar-paciente', async (req, res) => {
  const datosPaciente = req.body;
  try {
    const pacienteRegistrado = await insertarPaciente(datosPaciente);
    res.status(201).json(pacienteRegistrado);
  } catch (error) {
    console.error('Error al registrar paciente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta para obtener la lista de pacientes
app.get('/lista-pacientes', async (req, res) => {
  try {
    const pacientes = await obtenerListaPacientes();
    res.json(pacientes);
  } catch (error) {
    console.error('Error al obtener la lista de pacientes:', error);
    res.status(500).send('Error interno del servidor');
  }
});

// Función para obtener la lista de pacientes
async function obtenerListaPacientes() {
  const query = 'SELECT * FROM registro';
  try {
    const result = await pool.query(query);
    return result.rows;
  } catch (error) {
    throw error;
  }
}

app.get('/obtener-paciente/:id', async (req, res) => {
  const id = req.params.id;

  try {
      const paciente = await obtenerDetallesPaciente(id);
      res.json(paciente);
  } catch (error) {
      console.error('Error al obtener detalles del paciente para editar:', error);
      res.status(500).send('Error interno del servidor');
  }
});

// Función para obtener detalles de un paciente específico
async function obtenerDetallesPaciente(id) {
  const query = 'SELECT * FROM registro WHERE id = $1';
  try {
      const result = await pool.query(query, [id]);
      return result.rows[0];
  } catch (error) {
      throw error;
  }
}

// Función para eliminar un paciente
async function eliminarPaciente(id) {
  const query = 'DELETE FROM registro WHERE id = $1 RETURNING *';

  try {
    const result = await pool.query(query, [id]);
    return result.rows[0];
  } catch (error) {
    throw error;
  }
}

// Ruta para eliminar un paciente
app.delete('/eliminar-paciente/:id', async (req, res) => {
  const id = req.params.id;

  try {
    const pacienteEliminado = await eliminarPaciente(id);
    res.json({ message: 'Paciente eliminado con éxito' });
  } catch (error) {
    console.error('Error al eliminar paciente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

async function obtenerDatosPacienteAsync(idPaciente) {
  try {
    const query = 'SELECT * FROM registro WHERE id = $1';
    const result = await pool.query(query, [idPaciente]);

    if (result.rows.length > 0) {
      return result.rows[0];
    } else {
      throw new Error('Paciente no encontrado');
    }
  } catch (error) {
    throw error;
  }
}

// Ruta asíncrona para obtener datos de un paciente por su ID
app.get('/obtener-datos-paciente', async (req, res) => {
  try {
    const idPaciente = req.query.id;
    const datosPaciente = await obtenerDatosPacienteAsync(idPaciente);
    res.json(datosPaciente);
  } catch (error) {
    res.status(404).json({ mensaje: error.message });
  }
});

// Ruta para editar un paciente
app.put('/editar-paciente/:cedula', async (req, res) => {
  const cedula = req.params.cedula;
  const nuevosDatos = req.body;

  try {
    const pacienteActualizado = await actualizarPaciente(cedula, nuevosDatos);
    res.json(pacienteActualizado);
  } catch (error) {
    console.error('Error al editar paciente:', error);
    res.status(500).send('Error interno del servidor');
  }
});

// ... Resto del código ...

// Función para actualizar un paciente
async function actualizarPaciente(cedula, nuevosDatos) {
  const { mascota, raza, edad, sexo, color, residencia, nombre } = nuevosDatos;
  const query = 'UPDATE registro SET mascota = $1, raza = $2, edad = $3, sexo = $4, color = $5, residencia = $6, nombre = $7 WHERE cedula = $8 RETURNING *';
  const values = [mascota, raza, edad, sexo, color, residencia, nombre, cedula];

  try {
    const result = await pool.query(query, values);
    return result.rows[0];
  } catch (error) {
    throw error;
  }
}

const puerto = 3000;
app.listen(puerto, () => {
  console.log(`Servidor escuchando en el puerto ${puerto}`);
});
